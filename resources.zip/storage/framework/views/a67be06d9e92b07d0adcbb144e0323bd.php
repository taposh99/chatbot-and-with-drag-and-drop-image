<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel Install Botman Chatbot Example</title>
    </head>
    <body>
    </body>
   
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/botman-web-widget@0/build/assets/css/chat.min.css">
    <script src='https://cdn.jsdelivr.net/npm/botman-web-widget@0/build/js/widget.js'></script>
    <script>
        var botmanWidget = {
            aboutText: 'Botman',
            introMessage: "Hello! How may we help you?"
        };
    </script>
   
</html><?php /**PATH D:\server 4\htdocs\2024\chatboat\resources\views/home.blade.php ENDPATH**/ ?>